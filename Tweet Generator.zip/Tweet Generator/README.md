PLEASE WATCH THE FOLLOWING LOOM VIDEO:
https://www.loom.com/share/96745058c1d04567bfcf6845904cc66a?sid=e6f81eaa-6062-4e44-8bac-2082ef6334df

ALSO PLEASE SEE RUNTIME IMAGES IN THE IMAGES FOLDER INSIDE OF THE MAIN DIRECTORY

FINALLY BEFORE YOU READ, check out my github! : https://github.com/aabron

there is a requirements.txt in the main directory with all pip requirements you need to create a virtual enviornment

to install npm packages run npm install inside the "Tweet Generator" or base directory

to install python packages(if manually) use the command python -r -m requirements.txt
only do the above after creating a virtual environment

TO START DEVELOPMENT SERVER DJANGO:

to start the development django server, you must run python manage.py runserver while the venv is activated and you are inside the backend directory

TO START NODE DEVELOPMENT SERVER:

to start the node development server run npm run start in the /frontend folder, (NOTE: all node packages must be installed while cd'd in this folder)

purpose:
a basic and fun tweet generator technically anyone can use if you register for a x developer account

uses Open ai api, X V2 API, axios, django-rest-framework, token based authentication, cors, channels, request, oauth, react, and more

built by: Aaron Perel
Student ID: hg9724
